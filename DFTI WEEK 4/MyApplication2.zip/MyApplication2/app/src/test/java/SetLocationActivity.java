

public class SetLocationActivity {
}
