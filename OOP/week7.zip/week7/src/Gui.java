import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;

public class Gui extends JFrame{

	private JLabel lblRegNo;
	private JLabel lblOwner;
	private JLabel lblModel;
	private JLabel lblStatus;
	
	private JTextField txt_RegNo;
	private JTextField txt_Owner;
	private JTextField txt_Model;
	
	private JButton btnAdd;
	private JButton btnRem;
	
	public Gui() {
		carpark = new Carpark ();
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(new GridBagLayout());
	!!	GridBagConstraints constraints = new GridBagConstraints();
		
		initComponents();
		
		layoutComponents();
		
	}
	public void initComponents() {
		lblRegNo = new JLabel("Reg.No:");
		lblOwner = new JLabel("Owner's name:");
		lblModel = new JLabel ("Model:");
		lblStatus = new JLabel("Welcome");
		
		txt_RegNo = new JTextField();
		txt_Owner = new JTextField();
		txt_Model = new JTextField();
		
		btnAdd = new JButton("Add");
		btnRem = new JButton("Remove");
		
	}
	public void layoutComponents() {
		constraints.gridy=0;
		constraints.gridx=0;
				
		this.add(lblRegNo, constraints);
		
		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.gridy=0;
		constraints.gridx=1;
		
		this.add(txt_RegNo, constraints);
		
		constraints.fill = GridBagConstraints.NONE;
		constraints.gridy=1;
		constraints.gridx=0;
		
		this.add(lblOwner,constraints);

		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.gridy=1;
		constraints.gridx=1;
		
		this.add(txt_Owner,constraints);
		
		constraints.fill = GridBagConstraints.NONE;
		constraints.gridy=2;
		constraints.gridx=0;
		
		this.add(lblModel,constraints);
		
		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.gridy=2;
		constraints.gridx=1;
		
		this.add(txt_Model,constraints);
		
		constraints.fill = GridBagConstraints.NONE;
		constraints.gridy=3;
		constraints.gridx=0;
		constraints.gridwidth=2;
		
		this.ass(lblStatus,constraints);
		
		
		
		
	}
}
