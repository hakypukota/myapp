
public class motorbike {
	public double CalculateFee(){
		return 3;
	}
}
