
public class Program {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Car c1 = new Car();
		Car c2 = new Car("BMW","E46",0,70,50);
		
		c1.refuel();
		
		
	}

}
