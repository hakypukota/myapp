
public class Booking {

	private String name;
	private int numOfGuests;
	private boolean dineOutside;


	public Booking() {
		name = "Michael";
		numOfGuests = 12;
		dineOutside = true;
	}
	public static void main(String[] args) {
		

	}

}
