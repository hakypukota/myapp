
public class Staff {

	private String name;
	private String surname;
	private int age;
	
	public Staff(){
		name = "Jessica";
		surname = "Smith";
		age = 22;
	}

}
