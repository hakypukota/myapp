
public class Passenger {

	private String Name;
	private int Age;
	private int seat;
	
	public int getAge(){
		return Age;
	}
	public String getName(){
		return Name;
	}
	public int getSeat(){
		return seat;
	}
	public void setSeat(int seatIn){
		seat=seatIn;
	}

}
